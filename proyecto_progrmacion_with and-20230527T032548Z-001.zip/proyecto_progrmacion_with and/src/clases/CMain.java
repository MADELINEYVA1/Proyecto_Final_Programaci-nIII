
package clases;


import frames.login;
import frames.registrar_nuevo_empleado;
import frames.registrar_ubicacion;
import frames.ubicacion_producto;
import java.sql.SQLException;
import java.util.List;


    public class CMain {
       
        
        
    
     public static void main (String [] args) throws SQLException{
         
         login lo =new login();
         lo.setVisible(true);
        
       
         
         
    }

    public void main() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
     
      

    
}
