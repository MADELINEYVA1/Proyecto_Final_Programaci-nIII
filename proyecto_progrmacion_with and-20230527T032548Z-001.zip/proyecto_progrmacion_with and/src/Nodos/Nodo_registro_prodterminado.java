
package Nodos;


public class Nodo_registro_prodterminado {
    
    int idprodterminados;
    String nombreproducto;
    int cantidad;
    int no_lote;

    public int getIdprodterminados() {
        return idprodterminados;
    }

    public void setIdprodterminados(int idprodterminados) {
        this.idprodterminados = idprodterminados;
    }

    public String getNombreproducto() {
        return nombreproducto;
    }

    public void setNombreproducto(String nombreproducto) {
        this.nombreproducto = nombreproducto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public int getNo_lote() {
        return no_lote;
    }

    public void setNo_lote(int no_lote) {
        this.no_lote = no_lote;
    }
    
    
}
