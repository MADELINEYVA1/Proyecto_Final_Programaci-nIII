
package Nodos;

import java.util.ArrayList;

/**
 *
 * @author Windows 11
 */
public class Nodo_ubicacion {
    
    private int idubicacion;
    private String producto;
    private int estanteria;
    private int pasillo;
    private int nivel;

    public int getidubicacion() {
        return idubicacion;
    }

    public void setidubicacion(int idubicacion) {
        this.idubicacion = idubicacion;
    }

    public String getproducto() {
        return producto;
    }

    public void setproducto(String producto) {
        this.producto = producto;
    }

    public int getestanteria() {
        return estanteria;
    }

    public void setestanteria(int estanteria) {
        this.estanteria = estanteria;
    }

    public int getpasillo() {
        return pasillo;
    }

    public void setpasillo(int pasillo) {
        this.pasillo = pasillo;
    }

    public int getnivel() {
        return nivel;
    }

    public void setnivel(int nivel) {
        this.nivel = nivel;
    }


    
    
   
    

}
