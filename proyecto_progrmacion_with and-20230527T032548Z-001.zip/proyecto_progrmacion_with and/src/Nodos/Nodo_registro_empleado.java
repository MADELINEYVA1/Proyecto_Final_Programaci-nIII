
package Nodos;


public class Nodo_registro_empleado {
    
    private int DPI;
    private String Nombre;
    private String Apellido;
    private int edad;
    private int contraseña;

    public int getDPI() {
        return DPI;
    }

    public void setDPI(int DPI) {
        this.DPI = DPI;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getApellido() {
        return Apellido;
    }

    public void setApellido(String Apellido) {
        this.Apellido = Apellido;
    }

    public int getedad() {
        return edad;
    }

    public void setedad(int edad) {
        this.edad = edad;
    }

    public int getcontraseña() {
        return contraseña;
    }

    public void setcontraseña(int contraseña) {
        this.contraseña = contraseña;
    }
    
    
    
    
    
    
    
    
    
    
}
